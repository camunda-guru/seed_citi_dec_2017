/**
 * Created by BALASUBRAMANIAM on 08-01-2015.
 */

var dbref=window.indexedDB.open("EYDB",2);
dbref.onerror=function(evt)
{
  console.log("No Database Exists");

};
var db;
dbref.onsuccess=function(evt)
{
  db=evt.target.result;
  console.log("DB Opened");

};



function ReadData()
{

   var data=document.getElementById("custid");
   var trans = db.transaction(["Profiles"]);

   var objectStore= trans.objectStore("Profiles");
   var request=objectStore.get(parseInt(data.value));

    request.onerror=function(evt)
    {
         console.log("Not able to Retrieve data");
    };
    request.onsuccess=function(evt)
    {
       // alert("hi");
        if(request.result)
        {

            console.log(request.result.CustomerID+""+ request.result.Name+""+request.result.Photo);
        }

    };


}
