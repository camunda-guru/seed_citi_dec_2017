bankingApp.controller('FormController',['$scope','CountryService',function($scope,CountryService)
{
//model
    $scope.customerObj={
        firstName:"",
        lastName:"",
        dob:'',
        email:'',
        address:'',
        pincode:0,
        country:'',
        distance:0,
    }

    CountryService.countryListObj().then(function(response)
    {
        console.log(response);
    })


//form action
    $scope.save=function()
    {
        console.log($scope.customerObj);
    }


}])