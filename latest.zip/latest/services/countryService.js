serviceApp.service('CountryService',['$http',function($http)
{
    //function expression
    var countryList=function()
    {
        return $http({
            method: 'GET',
            dataType: "jsonp",
            headers: {
                'Content-Type': 'application/json'
            },
            url: 'https://restcountries.eu/rest/v2/all'

        }).then(function(res)
        {
            //console.log(res);
            return res;
        })
    }

    //singleton obj

    return{
        countryListObj:countryList
    }

}])